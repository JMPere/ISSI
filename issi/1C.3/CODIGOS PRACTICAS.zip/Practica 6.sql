/*CREATE TABLE empleados
        (cod_emp        integer,
        nom_emp         char(10)  not null,
        salario         number(9,2)  DEFAULT 100000,
        fecha_nac       date DEFAULT SYSDATE,
        comision        number(3,2) CHECK (comision>=0 AND comision <=1),
        cod_jefe        integer,
        
        PRIMARY KEY (cod_emp),
        FOREIGN KEY (cod_jefe) REFERENCES empleados ON DELETE CASCADE);
       
/*Secuencia*/ 
/*DROP SEQUENCE sec_emp;
CREATE SEQUENCE sec_emp INCREMENT BY 1 START WITH 1;

/*Procedimiento*/
/*CREATE OR REPLACE PROCEDURE contratar_empleado
(w_nom_emp IN empleados.nom_emp%TYPE,
w_salario IN empleados.salario%TYPE,
w_comision IN empleados.comision%TYPE,
w_cod_jefe IN empleados.cod_jefe%TYPE) is

BEGIN
INSERT INTO empleados (cod_emp, nom_emp, salario, comision, cod_jefe)
    VALUES (sec_emp.nextval, w_nom_emp, w_salario, w_comision, w_cod_jefe);
    COMMIT WORK;
END contratar_empleado;
/

EXECUTE contratar_empleado('Primero',1000,1,null);
EXECUTE contratar_empleado('Segundo',2000,TO_NUMBER('0,7'),null);
EXECUTE contratar_empleado('Tercero',2300,1,2);
SELECT*  FROM empleados;

/*Funcion*/
/*    CREATE OR REPLACE FUNCTION obtener_salario(w_cod_emp IN empleados.cod_emp%TYPE)
    RETURN NUMBER IS w_salario_bruto empleados.salario%TYPE;
    BEGIN
    SELECT salario*(1+comision) INTO w_salario_bruto FROM empleados
          WHERE cod_emp = w_cod_emp;
           RETURN (w_salario_bruto);
    END obtener_salario;
/
/*  Prueba de funci�n desde una instrucci�n SQL */
 /*   SELECT cod_emp,nom_emp,salario,comision,obtener_salario(cod_emp) 
    FROM empleados;
/*  Prueba de funci�n desde un bloque */
  /*  SET serveroutput ON;
    BEGIN
    DBMS_OUTPUT.PUT_LINE('Probando el salario de Manolo  '||' >>>> 
    '||obtener_salario(1));
    END;
    
/*Ejercicio 4*/
DROP TABLE empleados;
CREATE TABLE empleados
    (dni char(4) PRIMARY KEY,
    nomemp varchar2(15),
    cojefe char(4),
    FOREIGN KEY (cojefe) references empleados);
/*Inserta datos de ejemplo en la tabla*/

INSERT INTO empleados VALUES ('D1','Director',null);
INSERT INTO empleados VALUES ('D2','D.Comercial','D1');
INSERT INTO empleados VALUES ('D3','D.Producci�n','D1');
INSERT INTO empleados VALUES ('D4','Jefe Ventas','D2');
INSERT INTO empleados VALUES ('D5','Jefe Marketing','D2');
INSERT INTO empleados VALUES ('D6','Vendedor 1','D4');
INSERT INTO empleados VALUES ('D7','Vendedor 2','D4');
INSERT INTO empleados VALUES ('D8','Vendedor 3','D4');
INSERT INTO empleados VALUES ('D9','Vendedor 4','D4');
INSERT INTO empleados VALUES ('D10','Elba','D3');
INSERT INTO empleados VALUES ('D11','Obrero 2','D3');
INSERT INTO empleados VALUES ('D12','Obrero 3','D3');
INSERT INTO empleados VALUES ('D13','Secretario','D5');

SET SERVEROUTPUT ON
DECLARE CURSOR c IS
    SELECT cojefe, count(*) AS cuenta from empleados
    group by cojefe order by count(*) desc;
    /* group by cojefe order by 2 desc;*/
    
BEGIN
for fila in c loop
    exit when c%ROWCOUNT>3;
        DBMS_OUTPUT.PUT_LINE(fila.cojefe||' '||fila.cuenta);
END LOOP;  
end;