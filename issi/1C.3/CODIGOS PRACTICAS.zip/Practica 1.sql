CREATE TABLE prueba (
clave integer PRIMARY KEY,
descripcion varchar2(20));

INSERT INTO prueba VALUES (1, 'elemento primero');
commit;
INSERT INTO prueba VALUES (2, 'elemento segundo');

SELECT * FROM prueba;
/* WHERE clave=1; /*devuelve solo una fila