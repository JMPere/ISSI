CREATE TABLE empleados
(dni          char(9) PRIMARY KEY,
nomeemp       varchar2(50),
jefe          char(9),
departamento  integer,
salario       number(9,2) DEFAULT 1000,
usuario varchar2(50),
fecha date,
FOREIGN KEY (jefe) REFERENCES empleados(dni)
);

insert into empleados values (1, 'Pepe Lope', null, 10, 5000, 'pepelo', to_date('12/12/2018','dd/mm/yyyy'));

insert into empleados values (2, 'Maria Gi', 1, 10, 3000, 'mariagi', to_date('10/12/2018','dd/mm/yyyy'));

insert into empleados values (3, 'Pedro Gil', 1, 10, 1000, 'pedrogi', to_date('09/12/2018','dd/mm/yyyy'));

insert into empleados values (4, 'Jose Per', 1, 10, 200, 'joseper', to_date('08/12/2018','dd/mm/yyyy'));

insert into empleados values (5, 'Belen Dgue', 1, 10, 1000, 'belendo', to_date('09/12/2018','dd/mm/yyyy'));

insert into empleados values (6, 'Kike nun', 1, 10, 1500, 'kikenu', to_date('10/12/2018','dd/mm/yyyy'));


SELECT count(*)
FROM empleados
WHERE jefe=1
;

UPDATE EMPLEADOS SET salario = 1300 where dni=3;

commit;